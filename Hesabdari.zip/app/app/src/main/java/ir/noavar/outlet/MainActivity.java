package ir.noavar.outlet;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private ApiService apiService;
    private Button btn_on;
    private Button btn_off;
    private Button btn_local;
    private Spinner switchlist;
    private DataBaseOpenHelper dataBaseOpenHelper;
    String db_sn;
    String db_pass;


    @Override
    protected void onResume() {
        super.onResume();
        setContentView(R.layout.activity_main);

        dataBaseOpenHelper = new DataBaseOpenHelper(MainActivity.this);

        switchlist = findViewById(R.id.am_sp_sw);
        btn_on = findViewById(R.id.main_btn_on);
        btn_off = findViewById(R.id.main_btn_off);
        btn_local = findViewById(R.id.main_btn_local);
        TextView fab = findViewById(R.id.fab);

        btn_on.setOnClickListener(v -> {

            db_sn = dataBaseOpenHelper.getSN(FunctionsClass.numToEnglish(switchlist.getSelectedItem().toString()));
            db_pass = dataBaseOpenHelper.getPass(FunctionsClass.numToEnglish(switchlist.getSelectedItem().toString()));
            setonoff(db_sn, db_pass, "1");
        });

        btn_off.setOnClickListener(v -> {

            db_sn = dataBaseOpenHelper.getSN(FunctionsClass.numToEnglish(switchlist.getSelectedItem().toString()));
            db_pass = dataBaseOpenHelper.getPass(FunctionsClass.numToEnglish(switchlist.getSelectedItem().toString()));
            setonoff(db_sn, db_pass, "0");
        });

        btn_local.setOnClickListener(v -> startActivity(new Intent(MainActivity.this, LocalActivity.class)));

        fab.setOnClickListener(v -> startActivity(new Intent(MainActivity.this, AddActivity.class)));

        setSearchLayout();
    }


    public void setSearchLayout() {
        List<switchlist> switchList = dataBaseOpenHelper.getSwitchList();
        List<String> switch1 = new ArrayList<>();
        switch1.add("انتخاب کنید");
        for (int i = 1; i < switchList.size(); i++) {
            switch1.add(FunctionsClass.numToFarsi(switchList.get(i).getNameId()));
        }

        MySpinnerAdapter adapter = new MySpinnerAdapter(this, android.R.layout.simple_spinner_dropdown_item, switch1);
        switchlist.setAdapter(adapter);
    }

    private void setonoff(final String sn, final String pass, final String status) {
        apiService = new ApiService(MainActivity.this);
        apiService.setOnOff(sn, pass, status, (ok, msg) -> {
            if (ok.equalsIgnoreCase("true")) {
                FunctionsClass.showErrorSnak(MainActivity.this, FunctionsClass.getServerErrors(msg));
            } else {
                FunctionsClass.showErrorSnak(MainActivity.this, FunctionsClass.getServerErrors(msg));
            }

        });
    }
}