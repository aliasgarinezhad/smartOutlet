package ir.noavar.outlet;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

public class DataBaseOpenHelper extends SQLiteOpenHelper {

    private static final String DB_NAME = "db_switches";
    private static final int DB_VERSION = 1;
    private Context context;

    public DataBaseOpenHelper(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
        this.context = context;
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        createTable(DB_VERSION, db);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        createTable(newVersion, db);
    }

    private void createTable(int version, SQLiteDatabase db) {
        switch (version) {
            case 1:
                String querySwitches = "CREATE TABLE IF NOT EXISTS tb_switches (swsn TEXT, swpass TEXT, swname TEXT);";

                try {
                    db.execSQL(querySwitches);
                    ContentValues contentValues = new ContentValues();
                    contentValues.put("swsn", "null");
                    contentValues.put("swpass", "null");
                    contentValues.put("swname", "null");
                    db.insert("tb_switches", null, contentValues);

                } catch (SQLException e) {
                }
                break;
        }
    }

    public boolean setIdPass(String sn, String pass,String name) {
        ContentValues contentValues = new ContentValues();
        contentValues.put("swsn", sn);
        contentValues.put("swpass", pass);
        contentValues.put("swname", name);

        SQLiteDatabase sqLiteDatabase = this.getWritableDatabase();
        Cursor cursor = sqLiteDatabase.rawQuery("select swpass from tb_switches where swsn = '" + sn + "'", null);
        cursor.moveToFirst();

        if (cursor.getCount() > 0) {
            return false;
        }

        cursor = sqLiteDatabase.rawQuery("select swpass from tb_switches where swname = '" + name + "'", null);
        cursor.moveToFirst();

        if (cursor.getCount() > 0) {
            return false;
        }

        int rowEfected = (int) sqLiteDatabase.insert("tb_switches", null, contentValues);

        if (rowEfected > 0)
            return true;
        else
            return false;
    }

    public List<switchlist> getSwitchList() {
        List<switchlist> switchList = new ArrayList<>();

        SQLiteDatabase sqLiteDatabase = this.getReadableDatabase();
        Cursor cursor = sqLiteDatabase.rawQuery("select * from tb_switches", null);
        cursor.moveToFirst();

        if (cursor.getCount() > 0) {
            while (!cursor.isAfterLast()) {
                switchlist switches = new switchlist();
                switches.setNameId(cursor.getString(cursor.getColumnIndex("swname")));
                switchList.add(switches);
                cursor.moveToNext();
            }
        }
        cursor.close();
        sqLiteDatabase.close();
        return switchList;
    }

    public String getSN(String name) {
        SQLiteDatabase sqLiteDatabase = this.getReadableDatabase();
        Cursor cursor = sqLiteDatabase.rawQuery("select swsn from tb_switches where swname = '" + name + "'", null);
        cursor.moveToFirst();

        if (cursor.getCount() > 0) {
            if (!cursor.getString(0).equalsIgnoreCase("null"))
                return cursor.getString(0);
            else
                return "";
        }

        return "";
    }

    public String getPass(String name) {
        SQLiteDatabase sqLiteDatabase = this.getReadableDatabase();
        Cursor cursor = sqLiteDatabase.rawQuery("select swpass from tb_switches where swname = '" + name + "'", null);
        cursor.moveToFirst();

        if (cursor.getCount() > 0) {
            if (!cursor.getString(0).equalsIgnoreCase("null"))
                return cursor.getString(0);
            else
                return "";
        }

        return "";
    }


}
