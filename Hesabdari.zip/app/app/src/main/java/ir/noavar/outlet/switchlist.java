package ir.noavar.outlet;

/**
 * Created by Royal on 4/3/2018.
 */

public class switchlist {
    private String nameId;

    public String getNameId() {
        return nameId;
    }

    public void setNameId(String nameId) {
        this.nameId = nameId;
    }

}
