package ir.noavar.outlet;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class AddActivity extends AppCompatActivity {

    private ApiService apiService;
    private DataBaseOpenHelper dataBaseOpenHelper;
    private EditText UserName;
    private EditText PassWord;
    private EditText name;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add);

        UserName = findViewById(R.id.add_et_sn);
        PassWord = findViewById(R.id.add_et_pass);
        name = findViewById(R.id.add_et_name);
        dataBaseOpenHelper = new DataBaseOpenHelper(AddActivity.this);

        Button btnLogin = findViewById(R.id.add_btn_apply);
        btnLogin.setOnClickListener(v -> checkUserPass(FunctionsClass.numToEnglish(String.valueOf(UserName.getText()).trim()), FunctionsClass.numToEnglish(String.valueOf(PassWord.getText()).trim()), FunctionsClass.numToEnglish(String.valueOf(name.getText()).trim())));
    }

    private void checkUserPass(final String sn, final String pass, final String name) {
        apiService = new ApiService(AddActivity.this);
        apiService.checkUserPass(sn, pass, (ok, msg) -> {
            if (ok.equalsIgnoreCase("true")) {
                dataBaseOpenHelper.setIdPass(sn, pass, name);
                FunctionsClass.showErrorSnak(AddActivity.this, FunctionsClass.getServerErrors(msg));
            } else {
                if (msg.equalsIgnoreCase("003")) {

                } else {
                    FunctionsClass.showErrorSnak(AddActivity.this, FunctionsClass.getServerErrors(msg));
                }
            }

        });
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            finish();
        }
        return true;
    }
}