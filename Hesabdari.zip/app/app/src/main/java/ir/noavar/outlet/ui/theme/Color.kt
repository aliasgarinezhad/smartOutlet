package ir.noavar.outlet.ui.theme

import androidx.compose.ui.graphics.Color

val Blue = Color(0xFF4aa3df)
val Background = Color(0xFFecf5fb)
val doneColor = Color(0xFF00BFA5)
val errorColor = Color(0xFFe75f5f)